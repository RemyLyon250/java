/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game_server;

import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author lewis
 */
public class Game_Server {

    /**
     * @param args the command line arguments
     */
    
    
    public static ArrayList<Socket> currentUsers = new ArrayList<Socket>();
    public  static ArrayList<Player> players = new ArrayList<Player>();
    public static ArrayList<Question> questions = new ArrayList<Question>();
    public static int number=0;
    public static boolean answered=false;
    public static void main(String[] args) throws Exception{
        Question q1 = new Question("Kigali is the Capital of Rwanda?", "yes");
        Question q2 = new Question("Covid19 can kill?", "yes");
        Question q3 = new Question("Auca has only girls ?", "no");
        Question q4 = new Question("Jerome is a good teacher ?", "yes");
        Question q5 = new Question("God will stop lovinf us ?", "no");
        Question q6 = new Question("Jerome teaches maths?", "no");
        questions.add(q1);
        questions.add(q2);
        questions.add(q3);
        questions.add(q4);
        questions.add(q5);
        questions.add(q6);
        Game_Server server = new Game_Server();
        server.run();
    }
    
    public void run() throws Exception{
        ServerSocket Sock = new ServerSocket(4000);
        System.out.println("server is listenning on port 4000");
        while(true){
            Socket socket= Sock.accept();
            
            currentUsers.add(socket);
            
            addplayer(socket);
            
            Game_Thread game = new Game_Thread(socket);
            Thread x = new Thread(game);
            x.start();
           
        }
       
    }
    
    public void addplayer(Socket sock) throws IOException{
        Scanner INPUT = new Scanner(sock.getInputStream());
        String username = INPUT.nextLine();
        Player player = new Player(username);
        players.add(player);
        if(players.size()==2){
            for(Socket soc: Game_Server.currentUsers){
               Socket TEMP_SOCK =soc;
               PrintWriter TEMP_OUT = new PrintWriter(TEMP_SOCK.getOutputStream());
               TEMP_OUT.println("#?!Type Go to start the Exam \n");
               TEMP_OUT.flush();
           }
        }else if(players.size()>2){
            Socket temp_sock = Game_Server.currentUsers.get(Game_Server.currentUsers.size()-1);
            PrintWriter TEMP_OUT = new PrintWriter(temp_sock.getOutputStream());
            TEMP_OUT.println("#?!Type start to start the Game \n");
            TEMP_OUT.flush();
        }
    }
    
}
