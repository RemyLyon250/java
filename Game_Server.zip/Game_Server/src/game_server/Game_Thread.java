/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game_server;

import java.net.*;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author lewis
 */
public class Game_Thread implements Runnable {
    
    Socket Sock;
    private Scanner INPUT;
    private PrintWriter OUT;
    String answer;

    public Game_Thread(Socket Sock) {
        this.Sock = Sock;
    }
    
    
    
    
    
    public void run(){
        try {
            try {
                while(true){
                    INPUT = new Scanner(Sock.getInputStream());
                    OUT = new PrintWriter(Sock.getOutputStream());
                    
                    checkconnection();
                    if(!INPUT.hasNext()){
                        return;
                    }
                    answer = INPUT.nextLine();
                    //System.out.println(answer);
                    if(answer.contains(":") && !answer.contains("start") && !answer.contains("has disconnected")){
                        String[] play = answer.split(":");
                        for(Player user:Game_Server.players){
                            if(user.getName().equals(play[0])){
                                if(Game_Server.questions.get(Game_Server.number).getAnswer().equals(play[1])){
                                    int mark =  user.getMarks() + 1;
                                    user.setMarks(mark);
                                    Game_Server.answered=true;
                                }
                            }
                        }
                    }
                    
                    if(Game_Server.players.size()>=2){
                        if(Game_Server.number>=5){
                            int points=0;
                            Player winner = new Player();
                            for(Player pla: Game_Server.players){
                                if(pla.getMarks() > points){
                                    points=pla.getMarks();
                                    winner = pla;
                                }
                            }
                             
                            for(Socket sock: Game_Server.currentUsers){
                                Socket TEMP_SOCK =sock;
                               PrintWriter TEMP_OUT = new PrintWriter(TEMP_SOCK.getOutputStream());
                               TEMP_OUT.println("#?@The winner is "+ winner.getName() + "WIth 6 quedtions  with " +  winner.getMarks()+" correct answers" + winner.getMarks() );
                               TEMP_OUT.flush();
                           }
                            return;
                        }
                        if(Game_Server.answered){
                            Game_Server.number++;
                            Game_Server.answered=false;
                        }
                        for(Socket sock: Game_Server.currentUsers){
                            Socket TEMP_SOCK =sock;
                           PrintWriter TEMP_OUT = new PrintWriter(TEMP_SOCK.getOutputStream());
                           TEMP_OUT.println("Question"+(Game_Server.number+1)+": "+Game_Server.questions.get(Game_Server.number).getQuestion());
                           TEMP_OUT.flush();
                       }
                    }
                }
            }finally {
                Sock.close();
            }
        } catch (Exception e) {
           // e.printStackTrace();
        }
        
    }
    
    public void checkconnection() throws IOException{
        if(!Sock.isConnected()){
            for( Socket sock: Game_Server.currentUsers){
                if(sock==Sock){
                    Game_Server.currentUsers.remove(sock);
                }
            }
            
            for(Socket sock: Game_Server.currentUsers){
                 Socket TEMP_SOCK =sock;
                PrintWriter TEMP_OUT = new PrintWriter(TEMP_SOCK.getOutputStream());
                TEMP_OUT.println(TEMP_SOCK.getLocalAddress().getHostName() + "disconnected");
                TEMP_OUT.flush();
            }
            
        }
    }
    
}
