/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game_server;

/**
 *
 * @author lewis
 */
public class Player {
    public  String name;
    public  int marks=0;
    
    
    public  Player(String name, int marks){
        this.name=name;
        this.marks=marks;
    }

    public  Player(String name){
        this.name=name;
    }
    public Player() {
    }
    
    public void addMarks(int points){
        this.marks=this.marks+points;
    }

    public  String getName() {
        return name;
    }

    public  void setName(String name) {
        this.name = name;
    }

    public  int getMarks() {
        return marks;
    }

    public  void setMarks(int marks) {
        this.marks = marks;
    }
    
    
}
