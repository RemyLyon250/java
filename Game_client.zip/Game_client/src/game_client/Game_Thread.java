/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game_client;

import java.net.*;
import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author lewis
 */
public class Game_Thread implements Runnable{
    Socket Sock;
    Scanner INPUT;
    Scanner SEND = new Scanner(System.in);
    PrintWriter OUT;
    
    
    public Game_Thread(Socket Sock) {
        this.Sock = Sock;
    }
    
    
    
    public void run(){
        try {
            try {
                INPUT = new Scanner(Sock.getInputStream());
                OUT = new PrintWriter(Sock.getOutputStream());
                OUT.flush();
                checkStream();
            } finally {
                Sock.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public void checkStream(){
        while(true){
            Recieve();
        }
    }
    
    public void Recieve(){
        if(INPUT.hasNext()){
            String message= INPUT.nextLine();
            if(message.contains("#?@"))
            {
                String Temp = message.substring(3);
                Game_Client_view.send.setEnabled(false);
                Game_Client_view.questions.append("\n"+Temp + "\n" + "\nGame Ends Here");
            }
            else if(message.contains("#?!")){
                String Temp = message.substring(3);
                Game_Client_view.questions.append(Temp);
            }
            else{
                Game_Client_view.questions.append(message + "\n");
            }
        } 
    }
    
    public  void send(String message){
        OUT.println(Game_Client_view.Username + ":" +message);
        OUT.flush();
        Game_Client_view.message.setText("");
    }
    public  void disconnect() throws IOException{
        
        OUT.println(Game_Client_view.Username + ": has disconnected ");
        OUT.flush();
        Sock.close();
        JOptionPane.showMessageDialog(null, "You are disconnected");
        System.exit(0);
    }
}
